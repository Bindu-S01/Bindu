% Run the benchmark with nominal options
PrimesRun('1bit',1000000,'basic')
PrimesRun('8bit',1000000,'basic')
