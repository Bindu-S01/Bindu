rootProject.name = "PrimeSieve"
