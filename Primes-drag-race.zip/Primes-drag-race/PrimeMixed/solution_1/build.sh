#!/bin/sh

go build -o sieve_cgo sieve_cgo.go
