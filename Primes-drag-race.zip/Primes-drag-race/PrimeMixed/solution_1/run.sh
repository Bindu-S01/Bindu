#!/bin/sh

./sieve_cgo "$@"
