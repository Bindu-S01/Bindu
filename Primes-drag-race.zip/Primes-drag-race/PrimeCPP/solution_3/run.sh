#!/bin/bash
./build.sh && ./primes_constexpr
