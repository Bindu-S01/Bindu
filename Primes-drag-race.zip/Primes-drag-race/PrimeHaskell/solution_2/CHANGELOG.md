# Revision history for dragrace-haskell2

## 0.1.0.0 -- 2021-09-26

* Complete version including all five techniques and three "hybrid" compile options for 64, 128, and 256 bit registers.
* Also includes Multi-threading for all of the above five techniques on four threads.
