#!/bin/bash
for script in primes primes_bit
do
    ./${script}
    echo ""
done
