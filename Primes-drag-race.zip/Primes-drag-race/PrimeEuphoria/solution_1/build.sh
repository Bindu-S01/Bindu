#!/bin/bash
docker build . -t primes_euphoria:latest
