#!/bin/sh

janet main.janet
