retroassembler.exe -O=PRG .\primes.s .\primes.prg
