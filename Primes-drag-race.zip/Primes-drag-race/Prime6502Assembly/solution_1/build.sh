#!/bin/bash
dotnet retroassembler/retroassembler.dll -O=PRG ./primes.s ./primes.prg
