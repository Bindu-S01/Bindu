#!/bin/bash

./bin/cpp/Main
haxe interp.hxml
python3 bin/py.py