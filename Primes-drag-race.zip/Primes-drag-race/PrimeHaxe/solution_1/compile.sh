#!/bin/bash

haxelib install hxcpp

haxe cpp.hxml
haxe python.hxml
