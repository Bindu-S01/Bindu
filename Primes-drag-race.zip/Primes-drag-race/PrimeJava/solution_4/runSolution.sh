java -cp src PrimeSieveI32 -warmup
java -cp src PrimeSieveI32 -parallel -warmup
java -cp src PrimeSieveI32C -warmup
java -cp src PrimeSieveI32C -parallel -warmup
java -cp src PrimeSieveI64 -warmup
java -cp src PrimeSieveI64 -parallel -warmup
java -cp src PrimeSieveI64C -warmup
java -cp src PrimeSieveI64C -parallel -warmup
java -cp src PrimeSieveI64PatternCalc -warmup
java -cp src PrimeSieveI64PatternCalc -parallel -warmup
java -cp src PrimeSieveI8 -warmup
java -cp src PrimeSieveI8 -parallel -warmup
java -cp src PrimeSieveI32CUnroll -warmup
java -cp src PrimeSieveI32CUnroll -parallel -warmup
java -cp src PrimeSieveStrided32Blocks -warmup
java -cp src PrimeSieveStrided32Blocks -parallel -warmup
