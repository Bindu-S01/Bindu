#!/bin/bash

for file in *.java; do
    java $file
done
