#!/bin/bash
docker run --rm primes_beef:latest "$@"
