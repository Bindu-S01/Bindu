#!/bin/bash
docker build . -t primes_beef:latest
