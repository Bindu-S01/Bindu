#!/bin/sh

./primes_arm64_byte.run
./primes_arm64_bitmap.run
./primes_arm64_bitshift.run
