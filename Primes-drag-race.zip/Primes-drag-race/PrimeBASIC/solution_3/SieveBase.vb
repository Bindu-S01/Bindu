﻿MustInherit Class SieveBase
    Public MustOverride Function CountPrimes() As Integer
End Class
