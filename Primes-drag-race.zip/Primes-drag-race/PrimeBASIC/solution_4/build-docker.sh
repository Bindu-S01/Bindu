#!/bin/bash
docker build -t primes-basic-4 .
