#!/bin/bash
docker run --rm primes-basic-4
