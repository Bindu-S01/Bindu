# Delphi solution by JackTrapper

![Category](https://img.shields.io/badge/Category-faithful-green)

*Note from the maintainers: this solution is not included in the drag race due to a dependency on Delphi. Delphi is a commercial product that does provide a free Community Edition, but the limitations on its use are such that we cannot guarantee we would stay within the conditions of the license if we were to indeed use it.
