#!/bin/sh
for x in primes_words primes_striped-block; do
    ./$x
done
