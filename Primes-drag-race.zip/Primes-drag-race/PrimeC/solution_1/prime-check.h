// Prime count checks - number of primes less than x.
#define NUM_CHECKS 4
struct {
    int n;
    int piN;
} primeChecks[NUM_CHECKS] = {
    {1e6, 78498},
    {1e7, 664579},
    {1e8, 5761455},
    {1e9, 50847534},
    };
    