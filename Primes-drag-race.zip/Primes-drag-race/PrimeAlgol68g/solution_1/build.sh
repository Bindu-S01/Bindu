#!/bin/bash
docker build . -t primes_algol68g:latest

