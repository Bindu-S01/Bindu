#!/bin/bash
docker run --rm primes_algol68g:latest

