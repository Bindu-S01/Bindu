#!/bin/bash

clojure -T:build uber