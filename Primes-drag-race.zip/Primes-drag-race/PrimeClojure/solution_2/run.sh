#!/bin/sh

clojure -X sieve-8-bit/run
clojure -X sieve-1-bit/run
